#pragma once
#include<iomanip>
#include<string>
using namespace std;

class StringMagic
{
public:

	//Allows for word wrapping.  
	string wordWrap(string content, unsigned int width);
	bool isNumber(string compare);
	//Takes string value and converts it to an int returns -1 if a non-positive number is entered.
	int convertToInt(string number);
	//Makes a line of characters.
	string makeLineOf(char character, unsigned int length);

};