/*
Created By : Joe Saccente
For : IT 312
	Date : 12 / 13/ 2020
	Assignment : 7 - 1 Final
	Discussion : This application runs a game of farkle between at least two players but as many as the user would like to enter. 
	Please note, that the acompanying FarkleRules only seem to be accesasble if running the .exe directly and not through the Visual
	Studio IDE.  

	Throughout the course I have taken time to analyize and understand the problem statement and worked out a successfuly workflow
	to meet the demands.  Specifically, classes were written independently as the course went on so as to develop the codebase over time.
	Psudocode was also developed which allowed a clear understanding of the problem flow.  
		*/

#include "diceRoller.h"
#include "GameMechanics.h"
#include "Player.h"
#include "StringMagic.h"
#include <iostream>
#include <fstream>

	using namespace std;
/*Program main functions*/

int welcomeMenu(string userIn);

void setupPlayers(string &userIn, int &userChoice, vector<Player> &players);


int main()
{
	int userChoice = 0;
	string userIn;
	vector<Player> players;
	StringMagic str;

	do {

		userChoice = welcomeMenu(userIn);

		switch (userChoice) {
		case 1:
		{
			//Asks for number of players and player names.  
			setupPlayers(userIn, userChoice, players);
			cout << endl << str.makeLineOf('-', 80) << endl;

			//ask the player to what score they would like to play to, minimum of 2000 points.  
			do {

				cout << "What score would you like to play to? (10,000 is standard, cannot be less then 2,000)." << endl
					<< "#:: ";
				getline(cin, userIn);
			} while (str.convertToInt(userIn) < 2000);

			//setup game mechanics object with the given Fpoint target.
			GameMechanics mechanic(str.convertToInt(userIn));

			//looping through the avalible players until the target is reached.  
			int playerWhoHitGoalFirst = -1;
			do
			{
				for (unsigned int i = 0; i < players.size(); i++)
				{
					//running a game round for the current player
					mechanic.round(players.at(i));

					//checking to see if the player has hit the target score!
					if (mechanic.hasReachedTarget(players.at(i).getScore()))
					{
						playerWhoHitGoalFirst = players.at(i).id();
						break;
					}
				}

				system("cls");

				//displaying current scores of all the players
				cout << "The Current Line Up Is! " << endl;
				for (unsigned int i = 0; i < players.size(); i++)
				{
					cout << str.makeLineOf('-', 80);
					cout << players.at(i).getPlayerName() << " has " << players.at(i).getScore() << " banked." << endl;
					cout << str.makeLineOf('-', 80);
				}

				if (playerWhoHitGoalFirst != 0)
				{
					cout << "Good Luck in the next round!" << endl;
					system("pause");
				}
				else
				{
					cout << "We are entering the final round!" << endl;
				}

			} while (playerWhoHitGoalFirst == -1);

			//looping through all players except the one who hit the target last round.
			for (unsigned int i = 0; i < players.size(); i++)
			{
				if (i == playerWhoHitGoalFirst)
				{
					cout << "Sorry Skipping " << players.at(i).getPlayerName() << " since you hit the goal already!" << endl;
					system("pause");
				}
				else
				{
					//running a game round for the current player
					mechanic.round(players.at(i));
				}
			}

			//figuring out who came in first.
			int temp = 0;
			for (unsigned int i = 0; i < players.size(); i++)
			{
				if (temp < players.at(i).getScore())
				{
					//holding the location of the player with the largest score
					playerWhoHitGoalFirst = i;
					temp = players.at(i).getScore();
				}
			}

			cout << "The WINNER of this game is " << players.at(playerWhoHitGoalFirst).getPlayerName() << "!" << endl
				<< "Returning to main menu." << endl;
			system("pause");
			players.clear();
		}
			break;

			//Showing Game Manual.  
		case 2:
		{
			ifstream inFile("FarkleRules.txt", ios::in);
			string fileC = "";
			if (inFile.is_open())
			{
				while (!inFile.eof())
				{
					string temp;
					getline(inFile, temp);
					fileC = fileC + temp + "\n";
				}
			}

			inFile.close();
			cout << str.wordWrap(fileC, 80);
		}
			break;
		}

	} while (userChoice != 3);

	system("pause");
}

//displays welcome menue and allows the user to select if they would like to review the manual or 
//play the game/exit.  
int welcomeMenu(string userIn)
{
	StringMagic str;
	int choice = 0;
	do {
		cout << "Welcome to Farkle!" << endl
			<< "1) Play Game" << endl
			<< "2) View Manual" << endl
			<< "3) Exit" << endl
			<< str.makeLineOf('_', 10) << endl
			<< "#:: ";
		getline(cin, userIn);
		choice = str.convertToInt(userIn);
		system("cls");
	} while (choice >= 4 || choice <= 0);

	return choice;
}

//sets up players that will play the game
void setupPlayers(string &userIn, int &userChoice, vector<Player> &players)
{
	StringMagic str;
	userIn = "";
	//getting the number of players.
	do {
		cout << "How many players will there be? (minimum of 2)" << endl
			<< "#:: ";
		getline(cin, userIn);
		userChoice = str.convertToInt(userIn);
	} while (!str.isNumber(userIn) || userChoice <= 1);

	cout << "Ok, so what's everyone's names?" << endl;

	//getting the player names and setting up the player class for each.
	for (int i = 0; i < userChoice; i++)
	{
		userIn = "";
		while (userIn.size() <= 0)
		{
			cout << "Enter Player" << (i + 1) << " Name: ";
			getline(cin, userIn);
			if (userIn.size() < 0)
			{
				cout << "Please enter a player name with a length of at least 1." << endl;
			}
		}
		//adding player to the player vector.
		players.push_back(Player(userIn, i));
	}
}
