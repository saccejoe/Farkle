#pragma once
#include <time.h>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class DiceRoller
{
public:

	DiceRoller();
	unsigned int rollDie() const;
	vector<int> rollDie(int howMany) const;
	//pauses program execution for an amount of time
	void sleep(int time) const;
	//draws Die Faces die, excludes end line so multiples can be drawn on the same line.
	void drawDie(vector<int>& dice) const;

private:

	//strings to store the faces of the die and the 3 'rolling' views.
	string one;
	string two;
	string three;
	string four;
	string five;
	string six;
	string rolling1;
	string rolling2;
	string rolling3;

	//performs Dice rolling animations
	void rollAnimation(unsigned int timeBetweenF, unsigned int timeD, unsigned int dieCount) const;
	//depending on variables past particular part of the animation is shown.
	void animationPart(unsigned int dieCount, unsigned int part) const;
	//draws Die Faces die count will draw the same die across the same line.  
	void drawDie(unsigned int die, unsigned int dieCount) const;

};