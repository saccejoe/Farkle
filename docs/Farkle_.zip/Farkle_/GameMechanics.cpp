#include "GameMechanics.h"

//private functions

//collects the die that users would like to reroll
bool GameMechanics::reRollCollection(string userIn, bool dieToReroll[6]) const
{
	StringMagic str;
	userIn = "1";

	dieToReroll[0] = false;
	dieToReroll[1] = false;
	dieToReroll[2] = false;
	dieToReroll[3] = false;
	dieToReroll[4] = false;
	dieToReroll[5] = false; 

	while (str.convertToInt(userIn) != 0 && str.convertToInt(userIn) != -1)
	{
		cout << str.wordWrap("Select the Die positions you would like to reroll one at a time.  Enter 0 to end your turn and bank (if eligable) OR -1 (or any character to end your turn and ignore die you've entered for reroll.  Your points will still be banked if eligable.", 80);
		cout << endl << "#: ";
		getline(cin, userIn);

		//confirming a number has been entered and that it is within the die range 
		if (str.convertToInt(userIn) <= 6 && str.convertToInt(userIn) >= 1)
		{
			//assigning bool array the proper value if a die has been selected for reroll.
			switch (str.convertToInt(userIn)) {
			case 1:
				dieToReroll[0] = true;
				break;
			case 2:
				dieToReroll[1] = true;
				break;
			case 3:
				dieToReroll[2] = true;
				break;
			case 4:
				dieToReroll[3] = true;
				break;
			case 5:
				dieToReroll[4] = true;
				break;
			case 6:
				dieToReroll[5] = true;
			}

			cout << "Die number " << userIn << " will be rerolled. " << endl;

		}
		else if (str.convertToInt(userIn) == 0 || (str.convertToInt(userIn) == -1))
		{
			cout << "Turn Ending." << endl;
			if (str.convertToInt(userIn) == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			cout << "Please enter a valid number! 1-6. OR -1 to bank your points. OR 0 to end turn and ignore entries and end turn." << endl;
		}
	}
	return false;
}

bool GameMechanics::areAllDiePointDie(vector<int> playerDie) const
{
	//array to count how many duplicates and at which position
	int count[6] = { 0 };
	bool scoringDie[6] = { false };
	int dieLocations[4][6] = { {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1},  {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1} };
	//looping through player die and counting douplicates
	for (int i = 0; i < playerDie.size(); i++)
	{
		switch (playerDie.at(i)) {
		case 1:
			scoringDie[i] = true;
			break;
		case 2:
			count[1]++;
			for (int j = 0; j < 6; j++)
			{
				if (dieLocations[0][j] == -1)
				{
					dieLocations[0][j] == i;
				}
			}
			if (count[1] == 3)
			{
				for (int j = 0; j < 6; j++)
				{
					if (dieLocations[0][j] != -1)
					{
						scoringDie[j] == true;
					}
				}
			}
			break;
		case 3:
			count[2]++;
			for (int j = 0; j < 6; j++)
			{
				if (dieLocations[1][j] == -1)
				{
					dieLocations[1][j] == i;
				}
			}
			if (count[1] == 3)
			{
				for (int j = 0; j < 6; j++)
				{
					if (dieLocations[1][j] != -1)
					{
						scoringDie[j] == true;
					}
				}
			}
			break;
		case 4:
			count[3]++;
			for (int j = 0; j < 6; j++)
			{
				if (dieLocations[2][j] == -1)
				{
					dieLocations[2][j] == i;
				}
			}
			if (count[1] == 3)
			{
				for (int j = 0; j < 6; j++)
				{
					if (dieLocations[2][j] != -1)
					{
						scoringDie[j] == true;
					}
				}
			}
			break;
		case 5:
			scoringDie[i] = true;
			break;
		default:
			count[5]++;
			for (int j = 0; j < 6; j++)
			{
				if (dieLocations[3][j] == -1)
				{
					dieLocations[3][j] == i;
				}
			}
			if (count[1] == 3)
			{
				for (int j = 0; j < 6; j++)
				{
					if (dieLocations[3][j] != -1)
					{
						scoringDie[j] == true;
					}
				}
			}
		}
	}

	//setting scoringdie to true based on totals
	for (unsigned int i = 0; i < 6; i++)
	{
		if (count[i] % 3 == 0 && count[i] > 0)
		{
			if (count[i] > 3)
			{
				//all values are true
				scoringDie[0] = true;
				scoringDie[1] = true;
				scoringDie[2] = true;
				scoringDie[3] = true;
				scoringDie[4] = true;
				scoringDie[5] = true;
			}
		}
	}
	

	//checking if all die are scoring die
	int counter = 0;
	for (unsigned int i = 0; i < 6; i++)
	{
		if (scoringDie[i])
		{
			counter++;
		}
	}

	//Checking if all are true and returning true if so.
	if (counter == 6)
	{
		return true;
	}
	//returning total points avalible on the die.
	return false;
}

//Public Functions/Contstructor
//Constructor
GameMechanics::GameMechanics(unsigned int target)
{
	targetScore = target;
}

bool GameMechanics::hasReachedTarget(unsigned int playerScore) const
{
	if (playerScore >= targetScore)
	{
		return true;
	}
	return false;
}

//Returns the number of points rolled based on a vector of ints representing the face of each die.
//A 0 is returned if a Farkle has been rolled.
unsigned int GameMechanics::pointsRolled(vector<int> die) const
{
	unsigned int points = 0;
	//array to count how many duplicates
	int count[6] = { 0 };
	//loop through all of the die and provide a count of how many of each exist
	for (int i = 0; i < die.size(); i++)
	{
		switch (die.at(i)) {
		case 1:
			count[0]++;
			break;
		case 2:
			count[1]++;
			break;
		case 3:
			count[2]++;
			break;
		case 4:
			count[3]++;
			break;
		case 5:
			count[4]++;
			break;
		default:
			count[5]++;
		}
	}

	//looping through counted die for point totalling
	for (unsigned int i = 0; i < 6; i++)
	{
		//if one or 5 then special rules apply.  
		if (i == 0 || i == 4)
		{
			//switch statement breaks used only when needed to tally points depending on 1/5
			switch (count[i]) {
			case 6:
				if (i == 0)
				{
					points = points + 1000;
				}
				else
				{
					points = points + 500;
				}
				break;
			case 5:
				if (i == 0)
				{
					points = points + 100;
				}
				else
				{
					points = points + 50;
				}
			case 4:
				if (i == 0)
				{
					points = points + 100;
				}
				else
				{
					points = points + 50;
				}
			case 3:
				if (i == 0)
				{
					points = points + 1000;
				}
				else
				{
					points = points + 500;
				}
				break;
			case 2:
				if (i == 0)
				{
					points = points + 100;
				}
				else
				{
					points = points + 50;
				}
			case 1:
				if (i == 0)
				{
					points = points + 100;
				}
				else
				{
					points = points + 50;
				}
			}
		}
		//for every other die
		else
		{
			//check to see if there is a multiple of 3, if there is there are either 6 
			//of one kind or 3.
			int temp = 0;
			if (count[i] % 3 == 0 && count[i] > 0)
			{
				if (count[i] > 3)
				{
					//two times the 3 face bonus for having 6 of a kind
					temp = temp + ((i + 1) * 100);
					temp = temp + ((i + 1) * 100);
				}
				else
				{
					temp = temp + ((i + 1) * 100);
				}
				points = points + temp;
			}
			else
			{
				//if there are more then 3 but less then 6
				if (count[i] > 3)
				{
					temp = temp + ((i + 1) * 100);
					points = points + temp;
				}
			}
		}
	}
	//returning total points avalible on the die.
	return points;
}

//Returns True if the number of points rolled is greater then 1000
bool GameMechanics::rolledIn(vector<int> die) const
{
	if (pointsRolled(die) > 1000)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//returns True when the player ends their turn or false when they get a farkle
bool GameMechanics::round(Player &player) const
{
	StringMagic str;
	string userIn = "";
	bool dieToReroll [6] = { false };
	unsigned int playerPoints = 0;

	if (player.getRolledIn())
	{
		//Rolling player dice
		player.rollDice();
		cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
			<< str.makeLineOf('-', 80);
		//figuring out how many points they rolled
		playerPoints = pointsRolled(player.getPlayerDie());

		//let the player know they farkled end turn.
		if (playerPoints == 0)
		{
			cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
			system("pause");
			return false;
		}

		cout << player.getPlayerName() << " has rolled " << playerPoints << " so far.  " << endl
			<< player.getPlayerName() << "'s total commited score so far is " << player.getScore() << endl;

		//Giving the player an oportunity to reroll die if they want to.
		do {
			//asking and collecting reroll info.
			bool reRoll = reRollCollection(userIn, dieToReroll);

			if (reRoll)
			{
				//rerolling the selected die
				vector<int> newlyRolledDie = player.rollDice(dieToReroll);
				//Adding new points to the potentailly banked total.
				playerPoints = pointsRolled(player.getPlayerDie());

				//printing die identifications.
				cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
					<< str.makeLineOf('-', 80);
				//check to see if the player farkled
				if (pointsRolled(newlyRolledDie) == 0)
				{
					cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
					system("pause");
					return false;
				}
				//checking if all of the player's die are scoring die.
				if (areAllDiePointDie(player.getPlayerDie()))
				{
					system("pause");
					system("cls");
					cout << "ALL OF YOUR DIE ARE POINT DIE!! YOU NEED TO ROLL ONE MORE TIME." << endl
						<< "I hope " << player.getPlayerName() << " doesn't Farkle!" << endl
						<< player.getPlayerName() << "'s current point die score is " << playerPoints << "." << endl
						<< player.getPlayerName() << "'s commited score is " << player.getScore() << endl;
					system("pause");

					//Rolling player dice
					player.rollDice();
					cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
						<< str.makeLineOf('-', 80);

					//figuring out how many points they rolled and ensuring there was no farkle
					if (pointsRolled(player.getPlayerDie()) == 0)
					{
						cout << "Sorry "<< player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
						system("pause");
						return false;
					}
					else
					{
						cout << "Commiting your score of " << playerPoints << endl;
						system("pause");
						playerPoints = playerPoints + pointsRolled(player.getPlayerDie());
						userIn = "2";
					}
				}
				else
				{
					cout << str.makeLineOf('-', 80) << endl;
					cout << "Would you like to roll again?" << endl
						<< player.getPlayerName() << " Currently Rolled Point Total is " << playerPoints << "." << endl
						<< player.getPlayerName() << "'s commited score is " << player.getScore() << endl
						<< "1) yes" << endl
						<< "2) no" << endl
						<< "#:: ";
					getline(cin, userIn);
				}
			}
		} while (str.convertToInt(userIn) != 2);
	}
	else
	{
		//Rolling player dice
		player.rollDice();
		cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
			<< str.makeLineOf('-', 80);
		//figuring out how many points they rolled
		playerPoints = pointsRolled(player.getPlayerDie());

		//let the player know they farkled end turn.
		if (playerPoints == 0)
		{
			cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
			system("pause");
			return false;
		}

		cout << "You've rolled " << playerPoints << " so far.  ";
		//checking if the player rolled enough to enter the game.
		if (playerPoints >= 1000)
		{
			cout << "You've scored enough to enter the game! You can keep rolling if you would like." << endl;
		}
		else
		{
			cout << "Sorry " << player.getPlayerName() << " you haven't rolled enogh yet.  You'll need to keep rolling." << endl;

		}

		//Giving the player an oportunity to reroll die if they want to.
		do {
			//asking and collecting reroll info.
			bool reRoll = reRollCollection(userIn, dieToReroll);

			if (reRoll)
			{
				//rerolling the selected die
				vector<int> newlyRolledDie = player.rollDice(dieToReroll);
				//Adding new points to the potentailly banked total.
				playerPoints = pointsRolled(player.getPlayerDie());

				//printing die identifications.
				cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
					<< str.makeLineOf('-', 80);
				//check to see if the player farkled
				if (pointsRolled(newlyRolledDie) == 0)
				{
					cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
					system("pause");
					return false;
				}
			}


			//If the player rolled over 1000 points required to start banking they are given the option to
			//either roll again, or bank what they have.  If they rolled under they are forced to roll again.
			do {
				if (playerPoints >= 1000)
				{
					cout << str.makeLineOf('-', 80) << endl;
					cout << "Would you like to roll again?" << endl
						<< "Your Current Point Total is " << playerPoints << "." << endl
						<< "1) yes" << endl
						<< "2) no" << endl
						<< "#:: ";
					getline(cin, userIn);
				}
				else
				{
					cout << "Sorry but " << player.getPlayerName() << " haven't rolled enough to enter the game! You'll need to keep going." << endl;
					cout << player.getPlayerName() << "'s currently rolled point total is " << playerPoints << "." << endl;
					cout << str.makeLineOf('-', 80);
					//checking to see if all face die were had and still not at 1000
					if (userIn.compare("-2") == 0)
					{
						bool reRoll = reRollCollection(userIn, dieToReroll);

						//rerolling the selected die
						vector<int> newlyRolledDie = player.rollDice(dieToReroll);
						//Adding new points to the potentailly banked total.
						playerPoints = playerPoints + pointsRolled(player.getPlayerDie());

						//printing die identifications.
						cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
							<< str.makeLineOf('-', 80);
						//check to see if the player farkled
						if (pointsRolled(newlyRolledDie) == 0)
						{
							cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
							system("pause");
							return false;
						}
						userIn = "-2";
					}
					else
					{
						userIn = "1";
					}
				}

				//checks if all of the players die are point die.  If they are they are forced to roll 
				//all the die one more time.
				if (areAllDiePointDie(player.getPlayerDie()))
				{
					system("pause");
					system("cls");
					cout << "ALL OF YOUR DIE ARE POINT DIE!! YOU NEED TO ROLL ONE MORE TIME." << endl
						<< "I hope " << player.getPlayerName() << " doesn't Farkle!" << endl
						<< player.getPlayerName() << "'s current point die score is " << playerPoints << "." << endl;
					system("pause");

					//Rolling player dice
					player.rollDice();
					cout << "  [Die 1]      [Die 2]      [Die 3]      [Die 4]      [Die 5]      [Die6]" << endl << endl
						<< str.makeLineOf('-', 80);

					//figuring out how many points they rolled and ensuring there was no farkle
					if (pointsRolled(player.getPlayerDie()) == 0)
					{
						cout << "Sorry " << player.getPlayerName() << " rolled a Farkle! Your turn has ended." << endl;
						system("pause");
						return false;
					}
					else
					{
						playerPoints = playerPoints + pointsRolled(player.getPlayerDie());
						if (playerPoints >= 1000)
						{
							cout << "Commiting your score of " << playerPoints << endl;
							system("pause");
							userIn = "2";
						}
						else
						{
							userIn = "-2";
						}

					}
				}
			} while (str.convertToInt(userIn) != 1 && str.convertToInt(userIn) != 2);

			//resetting die to reroll
			for (int i = 0; i < 6; i++)
			{
				dieToReroll[i] = false;
			}

		} while (str.convertToInt(userIn) != 2);

	}
	player.updateScore(playerPoints);
	player.setRolledIn();
	cout << player.getPlayerName() << " commited " << playerPoints << " to their total. " << endl
		<< "Their current score is. " << player.getScore();

	return true;
}

