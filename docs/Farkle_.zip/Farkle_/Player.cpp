#include "Player.h"

//static DiceRoller shared across all players.
static DiceRoller roll;

//Private functions

/*
-------------------------------------
-------------------------------------
*/

//Public functions/constructors

//Player class constructor takes users name
Player::Player(string pName, unsigned int id)
{
	name = pName;
	playerID = id;
	rolledIn = false;
	score = 0;
}


//rolls all 6 die
void Player::rollDice()
{
	currentDice = roll.rollDie(6);
}

//rolls a particular die, this function will throw an error if it is called before rollDice has been called at
//least once.  The positinos that are True will be rerolled.
vector<int> Player::rollDice(bool positions[6])
{
	int counter = 0;
	//sweeping through the existing dice and setting the dice to be rerolled to 0
	//also incrementing a counter to find how many dice to reroll.
	for (unsigned int i = 0; i < 6; i++)
	{
		if (positions[i] == true)
		{
			currentDice.at(i) = 0;
			counter++;
		}
	}

	//temp vector to hold the Die the new die
	vector<int> tempDie = roll.rollDie(counter);

	//returns unchanged dice if 0 was passed.
	if (tempDie.at(0) == 0)
	{
		return currentDice;
	}
	else
	{
		//looping through the current dice looking for 0s.
		for (unsigned int i = 0; i < currentDice.size(); i++)
		{
			if (currentDice.at(i) == 0)
			{
				//assigning current die a new value at this location
				currentDice.at(i) = tempDie.at(counter - 1);
				//subtracting one from counter
				counter--;
			}
		}

		//drawing the new set of die.
		roll.drawDie(currentDice);
		return tempDie;
	}
}

//updates the players score
void Player::updateScore(unsigned int addPoints)
{
	score = score + addPoints;
}

//gets the players current score
unsigned int Player::getScore() const
{
	return score;
}

//returns the vector containing the users current dice
vector<int> Player::getPlayerDie() const
{
	return currentDice;
}

//sets the players current dice with a new array of die
void Player::setPlayerDie(vector<int> newDice)
{
	currentDice = newDice;
}

//returns the players ID
unsigned int Player::id() const
{
	return playerID;
}

//Returns the players Name.
string Player::getPlayerName() const
{
	return name;
}

//Returns true if the player is rolled in and their score cans start going up.
bool Player::getRolledIn() const
{
	if (rolledIn)
	{
		return true;
	}
	return false;
}

//sets the rolled in status to true
void Player::setRolledIn()
{
	rolledIn = true;
}