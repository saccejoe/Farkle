#include "StringMagic.h"

//This class provides some helper functions to format strings throught the rest of the program.  


string StringMagic::makeLineOf(char character, unsigned int length)
{
	string line = "";
	for (int i = 0; i < length; i++)
	{
		line = line + character;
	}
	line = line + "\n";
	return line;
}

//parses string and word wraps it. 
string StringMagic::wordWrap(string content, unsigned int width)
{
	string part = "";
	unsigned int counter = width;
	//go through the content string and assign parts to part when the end of
	//the line has been reached add a new line at the location of the last space unless there is 
	//already a new line there.
	for (int i = 0; i < content.size(); i++)
	{
		if (counter != 0)
		{
			part = part + content.at(i);
		}
		else if (counter == 0)
		{
			int space = part.find_last_of(' ');
			part.at(space) = '\n';
			counter = width;
		}
		counter--;
	}
	return part;
}

//implementation of isNumber, checks to ensure the string is a valid intager
bool StringMagic::isNumber(string compare)
{
	if (compare.find_first_not_of("0123456789") == compare.npos && compare.size() > 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//implementation of convertToInt, takes string value and converts it to an int returns -1 if a non-positive number is entered.
int StringMagic::convertToInt(string number)
{
	//checking to see if the string is a numnber (might seem redundent since we do this in main, but allows for the method
	//to be used in other places if the program expands and makes sure that the method always produces a valid response/doesn't
	//crash the program.  
	if (isNumber(number))
	{
		return stoi(number);
	}
	else
	{
		return -1;
	}
}