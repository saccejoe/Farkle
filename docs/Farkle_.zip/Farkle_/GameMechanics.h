#pragma once
#include "Player.h"
#include "StringMagic.h"
#include <iostream>
#include <vector>
using namespace std;

class GameMechanics
{
private:
	//target score representing the end goal of the game.
	unsigned int targetScore;

	//asks player which die they would like to reroll returns true if the player wants to reroll
	//returns false if they want to keep what they rolled and not continue rolling.
	bool reRollCollection(string userIn, bool dieToReroll[6]) const;
	//returns true if all point die are point die, an extra roll is required in this case.
	bool areAllDiePointDie(vector<int> playerDie) const;

public:
	//constructor
	GameMechanics(unsigned int target);
	//checks to see if a player has reached the target score and returns True if they have.
	bool hasReachedTarget(unsigned int playerScore) const;

	//returns the current total number of points rolled by a player.
	unsigned int pointsRolled(vector<int> die) const;

	//Returns True if the number of points rolled is greater then 1000
	bool rolledIn(vector<int> die) const;

	bool round(Player &player) const;
};

