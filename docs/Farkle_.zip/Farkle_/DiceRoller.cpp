#include "DiceRoller.h"


//Public Functions/Contstructor

//Constructor
DiceRoller::DiceRoller()
{
	//seeding the randome number generator with the current time.
	srand(time(NULL));
	one =
		"._________.\n"
		"|         |\n"
		"|         |\n"
		"|    *    |\n"
		"|         |\n"
		"|_________|\n";
	two =
		"._________.\n"
		"|         |\n"
		"| *       |\n"
		"|         |\n"
		"|       * |\n"
		"|_________|\n";
	three =
		"._________.\n"
		"|         |\n"
		"|       * |\n"
		"|    *    |\n"
		"| *       |\n"
		"|_________|\n";
	four =
		"._________.\n"
		"|         |\n"
		"| *     * |\n"
		"|         |\n"
		"| *     * |\n"
		"|_________|\n";
	five =
		"._________.\n"
		"|         |\n"
		"| *     * |\n"
		"|    *    |\n"
		"| *     * |\n"
		"|_________|\n";
	six =
		"._________.\n"
		"|         |\n"
		"| *     * |\n"
		"| *     * |\n"
		"| *     * |\n"
		"|_________|\n";
	rolling1 =
		"._________.\n"
		"|---------|\n"
		"|=========|\n"
		"|---------|\n"
		"|=========|\n"
		"|_________|\n";
	rolling2 =
		"._________.\n"
		"|\\//\\\\//\\ |\n"
		"|//\\//\\// |\n"
		"|\\//\\\\//\\ |\n"
		"|//\\//\\// |\n"
		"|_________|\n";
	rolling3 =
		"._________.\n"
		"|//\\//\\// |\n"
		"|\\//\\\\//\\ |\n"
		"|//\\//\\// |\n"
		"|\\//\\\\//\\ |\n"
		"|_________|\n";

}

//Rolls a single die and returns the result as an intager
unsigned int DiceRoller::rollDie() const
{
	unsigned int result = rand() % 6 + 1;
	rollAnimation(50, 75, 1);
	system("cls");
	drawDie(result, 1);
	return result;
}

//rolls a number of dice and returns a vector containing all of the results. 
//returns vector with one element that is 0 if no count is passsed
vector<int> DiceRoller::rollDie(int howMany) const
{
	vector<int> result;
	if (howMany > 0)
	{
		for (int i = 0; i < howMany; i++)
		{
			result.push_back(rand() % 6 + 1);
		}
		rollAnimation(50, 75, howMany);
		system("cls");
		drawDie(result);
		cout << endl;
		return result;
	}
	else
	{
		result.push_back(0);
		return result;
	}
}

//draws a number of dice based on a vector containing them in a row.
void DiceRoller::drawDie(vector<int>& dice) const
{
	string combinedDie;
	//outerloop loops through each horizonal line the dice are made up of
	for (unsigned int line = 0; line < 6; line++)
	{
		//inner loop gets the slice for each die in the set.
		for (unsigned int die = 0; die < dice.size(); die++)
		{
			switch (dice.at(die))
			{
			case 1:
				combinedDie = combinedDie + one.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
				break;
			case 2:
				combinedDie = combinedDie + two.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
				break;
			case 3:
				combinedDie = combinedDie + three.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
				break;
			case 4:
				combinedDie = combinedDie + four.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
				break;
			case 5:
				combinedDie = combinedDie + five.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
				break;
			default:
				combinedDie = combinedDie + six.substr((line * 12), 11);
				combinedDie = combinedDie + "  ";
			}
		}
		combinedDie = combinedDie + "\n";
	}
	cout << combinedDie << endl;
}

//pauses program execution for an amount of time
void DiceRoller::sleep(int time) const
{
	clock_t endTime;
	endTime = clock() + time * CLOCKS_PER_SEC / 1000;
	while (clock() < endTime)
	{
		//execute nothing while waiting
	}
}

/*
-------------------------------------
-------------------------------------
*/

//Private Functions Start

//Puts the animation sections together and spins them for a time based on the
//time input by the programmer - timeBetweenF is the time between frames and timeFrameD
//is the number of loops the animation runs for.
void DiceRoller::rollAnimation(unsigned int timeBetweenF, unsigned int timeD, unsigned int dieCount) const
{
	for (int i = 0; i < timeD; i++)
	{
		system("cls");
		//randomly selects a frame to display for all the die, could be any of the 
		//'animation' frames or a face of the die.
		animationPart(dieCount, rand() % 4 + 1);
		sleep(timeBetweenF);
	}
}

//Displays a particular frame of animation depending on programmer input, the dieCount is the number of 
//dice that will be shown and the part will be the frame shown.  
void DiceRoller::animationPart(unsigned int dieCount, unsigned int part) const
{
	switch (part)
	{
		//Displays Frame one
	case 1:
		//outer for loop designed to go through the 6 lines used to make the die
		for (int line = 0; line < 6; line++)
		{
			//inner for loop displays the line adds two blank spaces then displays the line for the next die
			//All dice will be in sync for this animation.  This loop structure is used for each frame.
			for (int die = 0; die < dieCount; die++)
			{
				cout << rolling1.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//Displays Frame two
	case 2:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << rolling2.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//displays Frame three
	case 3:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << rolling3.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//gets a random number between 1 and 6 and shows this face of the die as a frame
	default:
		drawDie(rand() % 6 + 1, dieCount);
	}
}

//draws the face of the die that was entered 1-6, die count is how many to show.
//this version of the function is used for the animationPart function call mostly.  
void DiceRoller::drawDie(unsigned int die, unsigned int dieCount) const
{
	switch (die)
	{
		//Showing die side one
	case 1:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << one.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//Showing die side two
	case 2:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << two.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//Showing die side three
	case 3:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << three.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//Showing die side four
	case 4:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << four.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//showing die side five
	case 5:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << five.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
		break;

		//showing die side six
	default:
		for (int line = 0; line < 6; line++)
		{
			for (int die = 0; die < dieCount; die++)
			{
				cout << six.substr((line * 12), 11);
				cout << "  ";
			}
			cout << endl;
		}
	}
}
