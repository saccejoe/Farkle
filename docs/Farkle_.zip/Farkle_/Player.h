#pragma once
#include <string>
#include <vector>
#include "DiceRoller.h"
using namespace std;

class Player
{
private:
	string name;
	unsigned int score, playerID;
	vector<int> currentDice;
	bool rolledIn;

public:
	//Standard Constructor
	Player(string pName, unsigned int id);


	//Rolls all 6 die when version that doesn't take an int is called rolls
	//only the die in the positions given in the version that takes a vector
	void rollDice();
	vector<int> rollDice(bool positions[6]);

	//Updates and get's the players score
	void updateScore(unsigned int newScore);
	unsigned int getScore() const;

	//get Players current Dice (useful for the gamelogic class)
	vector<int> getPlayerDie() const;
	//update Player die
	void setPlayerDie(vector<int> newDice);

	//Get PlayerID
	unsigned int id() const;

	//Get Player Name
	string getPlayerName() const;

	//Get if they player has rolled into the game or not (can they score yet)
	bool getRolledIn() const;

	//Allows for the players rolled in status to be set. 
	void setRolledIn();
};

